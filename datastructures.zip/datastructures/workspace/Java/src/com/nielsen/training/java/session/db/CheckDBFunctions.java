package com.nielsen.training.java.session.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class CheckDBFunctions {
	
	public static void createTable(Connection conn) throws SQLException {
		Statement st = conn.createStatement();
		st.execute("CREATE TABLE IF NOT EXISTS contacts name VARCHAR , phone NUMBER, email VARCHAR");
	}
	
	public static void main(String args[]) {
		//try with resources - https://docs.oracle.com/javase/tutorial/essential/exceptions/tryResourceClose.html
		try(Connection conn = ConnectionFactory.getConnection()){
			createTable(conn);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}

}
