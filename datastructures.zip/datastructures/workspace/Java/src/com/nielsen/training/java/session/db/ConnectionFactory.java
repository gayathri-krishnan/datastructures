package com.nielsen.training.java.session.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import org.apache.derby.jdbc.EmbeddedDriver;
/**
 * This class created a database
 * @author krga9002
 *
 */
public class ConnectionFactory {

	public static Connection getConnection() throws SQLException {
		String dbURL = "jdbc:derby:webdb;create=true";
		DriverManager.registerDriver(new org.apache.derby.jdbc.EmbeddedDriver());
		Connection conn = DriverManager.getConnection(dbURL);
		return conn;
	}
	
}
