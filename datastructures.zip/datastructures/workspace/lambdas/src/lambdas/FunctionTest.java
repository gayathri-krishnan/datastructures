package lambdas;

public class FunctionTest {

}
